// A C program to demonstrate buffer overflow 
#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
  
int main() 
{ 
       // Reserve 5 byte of buffer 
       // should allocate 5 characters, 
       // To overflow, need more than 5 characters... 
       char buffer[5];  // If more than 5 characters input 
                        // by user, there will be access  
                        // violation, segmentation fault 
       
        
       // get the user input to buffer, without any bound checking 
       // gets(buffer); 
       
       // 5+1 is because of the final NULL character
       fgets(buffer,6,stdin);
       
       printf("buffer content= %s\n", buffer); 
  
       return 0; 
} 