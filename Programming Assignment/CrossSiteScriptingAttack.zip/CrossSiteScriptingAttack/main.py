import webbrowser


def input_checker(value):
    return value.isalpha()


def encode(value):
    ans = ""
    for c in list(value):
        if c == '&':
            ans = ans + c + "amp;"
        elif c == '<':
            ans = ans + c + "&lt;"
        elif c == '>':
            ans = ans + c + "&gt;"
        else:
            ans = ans + c
    return ans

if __name__ == "__main__":

    value = input("Please enter a query:\n")

    # if input_checker(value) == False:
    #     print('Input is not valid!')
    # else:
    value = "https://xss-game.appspot.com/level1/frame?query=" + value
    value = encode(value)
    webbrowser.open(value, new=2)
